﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoLib
{
    public class Truck : Auto
    {
        public Truck(int doors, string make, string model, decimal price, double bedSize) : base(doors, make, model, price)
        {
            BedSize = bedSize;
        }

        public double BedSize { get; set; }

        public override string MakeSound()
        {
            return "Honk, Honk";
        }
        public override int DoubleSpeed(int speed)
        {
            return speed * 2;

        }
    }
}
