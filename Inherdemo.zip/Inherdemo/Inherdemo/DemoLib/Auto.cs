﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DemoLib
{
    //now nothing can be instantiated from this class because no object can be created. so that way this is the base class and will inherit to the other classes like truck and car. 
    public abstract class Auto
    {
        // Parent Class
        public Auto(int doors, string make, string model, decimal price)
        {
            Doors = doors;
            Make = make;
            Model = model;
            Price = price;

        }

        public int Doors {get; set;}
        public string Make { get; set; }
        public string Model { get; set; }
        public decimal Price { get; set; }

        public virtual string MakeSound()
        {
            return "Zoom, Zoom";
        }


        public abstract int DoubleSpeed(int speed);
    
    }
}
