﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DemoLib;

namespace ConsoleUI
{
    class Program
    {
        static void Main(string[] args)
        {
            Car myCar = new Car(4, "Ford", "Escort", 35000, 10);
            Truck myTruck = new Truck(2, "Dodge", "Ram", 37000, 6);

            List<Auto> autos = new List<Auto>();

            autos.Add(myCar);
            autos.Add(myTruck);

            Console.WriteLine(myCar.MakeSound());
            Console.WriteLine(myTruck.DoubleSpeed(10));






            Console.ReadLine();
        }
    }
}
