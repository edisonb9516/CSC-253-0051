﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WordCountLib
{
    public class WordCount
    {
        //this class library is going to take the user string from the form and count the words within the string 
        public static string countWord(string userInput) 
        {
            //create var to hold total of words
            int totalWords = 0;

            //get the tokens into the array from the string
            string[] tokens = userInput.Split(null);

            //create a loop that will count the number of tokens and add to a variable
            foreach (string word in tokens)
            {
                totalWords += 1;
            }

            return totalWords.ToString();
        
        }

        public static string averageWord(string userInput) 
        {
            //this method is going to average the number of letters in each word of the string the user entered

            
            int avgLetters = 0;

            
            
            return avgLetters.ToString();
        }
    }
}
